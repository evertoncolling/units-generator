from cognite.client import CogniteClient
from cognite.client.utils import datetime_to_ms
from datetime import datetime, timezone
from typing import Literal
import json
import re
from cognite.routine_builder._validators import (
    is_valid_timeseries,
    check_units,
    check_object_map,
    check_command_map,
)
from cognite.routine_builder.utils import (
    get_abbreviation,
    calculate_granularity_time,
    generate_time_series_external_id,
)
from cognite.routine_builder.sdk import SimIntSDK


class RoutineRevisionBuilder(object):
    __payload_item: dict
    __configuration: dict
    __script: list[dict]
    __input_var_ids: list[str]
    __output_var_ids: list[str]
    __n_groups: int
    __routine: dict
    __simulator: dict
    __client: CogniteClient
    __sim_int_sdk: SimIntSDK

    def __init__(
        self,
        external_id: str,
        routine_external_id: str,
        client: CogniteClient,
    ) -> None:
        """
        Initializes a RoutineRevisionBuilder object.

        Args:
            external_id (str): The external ID of the routine revision.
            routine_external_id (str): The external ID of the associated routine.
            client (CogniteClient): The CogniteClient object used to interact with the Cognite Data Fusion (CDF) API.
        """
        # input validation
        if not isinstance(external_id, str):
            raise ValueError("external_id needs to be of type string")

        if not isinstance(routine_external_id, str):
            raise ValueError("routine_external_id needs to be of type string")

        if not isinstance(client, CogniteClient):
            raise ValueError("client needs to be of type CogniteClient")

        self.__client = client
        self.__sim_int_sdk = SimIntSDK(self.__client)

        routine = self.__sim_int_sdk.retrieve_routine(routine_external_id)
        if not routine:
            raise ValueError("The provided routine_external_id does not exist in CDF")
        self.__routine = routine

        simulator_external_id = self.__routine["simulatorExternalId"]
        self.__simulator = self.__sim_int_sdk.retrieve_simulator(simulator_external_id)

        self.__configuration = {
            "schedule": {
                "enabled": False,
            },
            "dataSampling": {
                "validationWindow": 60,
                "samplingWindow": 60,
                "granularity": 1,
                "validationEndOffset": "0m",
            },
            "logicalCheck": {
                "enabled": False,
            },
            "steadyStateDetection": {
                "enabled": False,
            },
            "inputConstants": [],
            "inputTimeseries": [],
            "outputTimeseries": [],
        }

        self.__n_groups = 1
        self.__script = []
        self.__input_var_ids = []
        self.__output_var_ids = []
        self.__payload_item = {
            "externalId": external_id,
            "routineExternalId": routine_external_id,
            "configuration": self.__configuration,
            "script": self.__script,
        }

    def __str__(self) -> str:
        return f"""RoutineRevisionBuilder
externalId: {self.__payload_item.get("externalId")}
routineExternalId: {self.__payload_item.get("routineExternalId")}"""

    def __repr__(self) -> str:
        return self.__str__()

    def configure_schedule(
        self,
        repeat: str = "1d",
        start_time: int | None = None,
        enabled: bool = True,
    ) -> None:
        """
        Configures the schedule for the routine revision.

        Args:
            repeat (str, optional): The repeat pattern for the schedule. Defaults to "1d".
            start_time (int, optional): The start time for the schedule in milliseconds. Defaults to now.
            enabled (bool, optional): Whether the schedule is enabled or not. Defaults to True.
        """
        # input validation
        if not isinstance(enabled, bool):
            raise ValueError("enabled needs to be of type bool")

        if not enabled:
            self.__configuration["schedule"] = {"enabled": False}
            return

        if start_time and (not isinstance(start_time, int)):
            raise ValueError("start_time needs to be of type int")

        if not isinstance(repeat, str):
            raise ValueError("repeat needs to be of type string")

        if not re.match(r"^([0-9]|[1-9][0-9])[s|m|h|d|w]$", repeat):
            raise ValueError("Invalid repeat pattern")

        # make sure the data sampling is compatible with the schedule frequency
        repeat_timedelta = calculate_granularity_time(repeat)
        if (
            self.__configuration["dataSampling"]["validationWindow"] * 60000
            > repeat_timedelta
        ):
            self.__configuration["dataSampling"]["validationWindow"] = int(
                repeat_timedelta / 60000
            )
        if (
            self.__configuration["dataSampling"]["samplingWindow"] * 60000
            > repeat_timedelta
        ):
            self.__configuration["dataSampling"]["samplingWindow"] = int(
                repeat_timedelta / 60000
            )

        start_time = (
            start_time if start_time else datetime_to_ms(datetime.now(timezone.utc))
        )

        self.__configuration["schedule"] = {
            "enabled": True,
            "startTime": start_time,
            "repeat": repeat,
        }

    def configure_data_sampling(
        self,
        validation_window: int = 60,
        sampling_window: int = 60,
        granularity: int = 1,
        validation_end_offset: str = "0m",
    ) -> None:
        """
        Configures the data sampling parameters for the routine.

        Args:
            validation_window (int): The length of the validation window in minutes. Default is 60.
            sampling_window (int): The length of the sampling window in minutes. Default is 60.
            granularity (int): The granularity of the data sampling in minutes. Default is 1.
            validation_end_offset (str): The offset from the end of the validation window.
                Should be in the format of '[number][unit]', where unit can be 's' (seconds),
                'm' (minutes), 'h' (hours), 'd' (days), or 'w' (weeks). Default is '0m'.
        """
        # input validation
        if not isinstance(validation_window, int):
            raise ValueError("validation_window needs to be of type int")

        if not isinstance(sampling_window, int):
            raise ValueError("sampling_window needs to be of type int")

        if not isinstance(granularity, int):
            raise ValueError("granularity needs to be of type int")

        if not isinstance(validation_end_offset, str):
            raise ValueError("validation_end_offset needs to be of type string")

        if not re.match(r"^([0-9]|[1-9][0-9])[s|m|h|d|w]$", validation_end_offset):
            raise ValueError("Invalid validation_end_offset pattern")

        if sampling_window > validation_window:
            raise ValueError(
                "sampling_window cannot be larger than the validation_window"
            )

        # make sure the data sampling is compatible with the schedule frequency
        repeat = self.__configuration["schedule"].get("repeat")
        if repeat:
            repeat_timedelta = calculate_granularity_time(repeat)
            if validation_window * 60000 > repeat_timedelta:
                raise ValueError(
                    "validation_window cannot be larger than the frequency of the schedule"
                )
            if sampling_window * 60000 > repeat_timedelta:
                raise ValueError(
                    "sampling_window cannot be larger than the frequency of the schedule"
                )

        self.__configuration["dataSampling"] = {
            "validationWindow": validation_window,
            "samplingWindow": sampling_window,
            "granularity": granularity,
            "validationEndOffset": validation_end_offset,
        }

    def configure_logical_check(
        self,
        time_series_external_id: str = "",
        aggregate: Literal["average", "interpolation", "stepInterpolation"] = "average",
        operator: Literal["eq", "ne", "gt", "ge", "lt", "le"] = "eq",
        value: float | int = 0.0,
        enabled: bool = True,
    ) -> None:
        """
        Configures the logical check for the routine.

        Args:
            time_series_external_id (str): The external ID of the time series to be checked.
            aggregate (Literal["average", "interpolation", "stepInterpolation"]): The aggregation method to be used for the check.
            operator (Literal["eq", "ne", "gt", "ge", "lt", "le"]): The comparison operator to be used for the check.
            value (float | int): The value to be compared against.
            enabled (bool): Indicates whether the logical check is enabled or not.
        """
        # input validation
        if not isinstance(enabled, bool):
            raise ValueError("enabled needs to be of type bool")

        if not enabled:
            self.__configuration["logicalCheck"] = {"enabled": False}
            return

        if not isinstance(time_series_external_id, str):
            raise ValueError("time_series_external_id needs to be of type string")

        if not isinstance(aggregate, str):
            raise ValueError("aggregate needs to be of type string")

        if aggregate not in ["average", "interpolation", "stepInterpolation"]:
            raise ValueError(f"invalid value for aggregation: {aggregate}")

        if not isinstance(operator, str):
            raise ValueError("operator needs to be of type string")

        if operator not in ["eq", "ne", "gt", "ge", "lt", "le"]:
            raise ValueError(f"invalid check operator: {operator}")

        if not isinstance(value, (float, int)):
            raise ValueError("value needs to be of type float or int")

        if not is_valid_timeseries(time_series_external_id, self.__client):
            raise ValueError("Provided time_series_external_id does not exist in CDF")

        self.__configuration["logicalCheck"] = {
            "enabled": True,
            "timeseriesExternalId": time_series_external_id,
            "aggregate": aggregate,
            "operator": operator,
            "value": value,
        }

    def configure_steady_state_detection(
        self,
        time_series_external_id: str = "",
        aggregate: Literal["average", "interpolation", "stepInterpolation"] = "average",
        min_section_size: int = 1,
        var_threshold: float | int = 3.0,
        slope_threshold: float | int = -3.5,
        enabled: bool = True,
    ) -> None:
        """
        Configures the steady state detection settings for the routine.

        Args:
            time_series_external_id (str): The external ID of the time series to be analyzed.
            aggregate (Literal["average", "interpolation", "stepInterpolation"]): The type of aggregation to be used.
            min_section_size (int): The minimum section size for change point detection.
            var_threshold (float | int): The variance threshold in the time series data.
            slope_threshold (float | int): The slope threshold in the time series data.
            enabled (bool): Whether steady state detection is enabled or not.
        """
        # input validation
        if not isinstance(enabled, bool):
            raise ValueError("enabled needs to be of type bool")

        if not enabled:
            self.__configuration["steadyStateDetection"] = {"enabled": False}
            return

        if not isinstance(time_series_external_id, str):
            raise ValueError("external_id needs to be of type string")

        if not isinstance(aggregate, str):
            raise ValueError("aggregation needs to be of type string")

        if aggregate not in ["average", "interpolation", "stepInterpolation"]:
            raise ValueError(f"invalid value for aggregation: {aggregate}")

        if not isinstance(min_section_size, int):
            raise ValueError("min_section_size needs to be of type int")

        if not isinstance(var_threshold, (float, int)):
            raise ValueError("var_threshold needs to be of type float or int")

        if not isinstance(slope_threshold, (float, int)):
            raise ValueError("slope_threshold needs to be of type float or int")

        if not is_valid_timeseries(time_series_external_id, self.__client):
            raise ValueError("Provided time_series_external_id does not exist in CDF")

        self.__configuration["steadyStateDetection"] = {
            "enabled": True,
            "timeseriesExternalId": time_series_external_id,
            "aggregate": aggregate,
            "minSectionSize": min_section_size,
            "varThreshold": var_threshold,
            "slopeThreshold": slope_threshold,
        }

    def add_group(self, description: str) -> None:
        """
        Adds a group to the routine.

        Args:
            description (str): The description of the group.
        """
        # input validation
        if not isinstance(description, str):
            raise ValueError("description needs to be of type string")

        if self.__n_groups == 10:
            raise ValueError("The maximum number of groups is 10")

        # add the group
        self.__script.append(
            {"order": self.__n_groups, "description": description, "steps": []}
        )

        # update the counter
        self.__n_groups += 1

    def __generic_set_get_step(
        self,
        group: int,
        name: str,
        object_map: dict[str, str],
        description: str | None = None,
        unit: str | None = None,
        unit_type: str | None = None,
        save_time_series_external_id: str | None = None,
        reference_id: str | None = None,
        step_type: Literal["SetConstant", "SetTimeSeries", "Get"] = "SetConstant",
        value: str | float | int | None = None,
        source_external_id: str | None = None,
        aggregate: (
            Literal["average", "interpolation", "stepInterpolation"] | None
        ) = None,
    ) -> tuple[str, str]:
        # input validation
        if not isinstance(group, int):
            raise ValueError("group needs to be of type int")

        if len(self.__script) == 0:
            raise ValueError("No groups found, please add a group first")

        if (group > self.__n_groups + 1) or (group <= 0):
            raise ValueError("Invalid value for group")

        if description and not isinstance(description, str):
            raise ValueError("description needs to be of type string")

        if not isinstance(name, str):
            raise ValueError("name needs to be of type string")

        if not isinstance(object_map, dict):
            raise ValueError("object_map needs to be of type dictionary")

        if unit and (not isinstance(unit, str)):
            raise ValueError("unit needs to be of type string")

        if unit_type and (not isinstance(unit_type, str)):
            raise ValueError("unit_type needs to be of type string")

        # if unit is string, unit_type must be string too
        if unit and not unit_type:
            raise ValueError(
                "if unit is provided, unit_type needs to be of type string"
            )

        if unit_type and not unit:
            raise ValueError(
                "if unit_type is provided, unit needs to be of type string"
            )

        if step_type == "SetConstant":
            if not isinstance(value, (str, float, int)):
                raise ValueError("value needs to be of type string, float or int")

        elif step_type == "SetTimeSeries":
            if not isinstance(source_external_id, str):
                raise ValueError("source_external_id needs to be of type string")

            if aggregate not in ["average", "interpolation", "stepInterpolation"]:
                raise ValueError(f"Invalid value for aggregation: {aggregate}")

            if not is_valid_timeseries(source_external_id, self.__client):
                raise ValueError("Provided source_external_id does not exist in CDF")

        # check if the unit and unit_type are valid for the simulator
        if unit and unit_type:
            check_units(unit, unit_type, self.__simulator)

        # check if the passed dictionary contains all the variables needed for the simulator
        check_object_map(object_map, self.__simulator)

        # if no reference_id is given we can generate one from the name
        reference_id = reference_id if reference_id else get_abbreviation(name)

        if step_type in ["SetConstant", "SetTimeSeries"]:
            # check if the variable id is unique
            if reference_id in self.__input_var_ids:
                raise ValueError(
                    f"Invalid reference_id ({reference_id}), this value already exists"
                )

            self.__input_var_ids.append(reference_id)
        elif step_type == "Get":
            # check if the variable id is unique
            if reference_id in self.__output_var_ids:
                raise ValueError(
                    f"Invalid reference_id ({reference_id}), this value already exists"
                )

            self.__output_var_ids.append(reference_id)

        # if no save_time_series_external_id is given we can generate one from the name
        save_time_series_external_id = (
            save_time_series_external_id
            if save_time_series_external_id
            else generate_time_series_external_id(
                simulator=self.__simulator,
                routine=self.__routine,
                reference_id=reference_id,
                variable_type=(
                    "INPUT"
                    if step_type in ["SetConstant", "SetTimeSeries"]
                    else "OUTPUT"
                ),
            )
        )

        return reference_id, save_time_series_external_id

    def add_set_step_input_constant(
        self,
        group: int,
        name: str,
        value: str | float | int,
        object_map: dict[str, str],
        description: str | None = None,
        unit: str | None = None,
        unit_type: str | None = None,
        save_time_series_external_id: str | None = None,
        reference_id: str | None = None,
    ) -> None:
        """
        Adds an input constant set step in the routine.

        Args:
            group (int): The group number of the step.
            name (str): The name of the input constant.
            value (str | float | int): The value of the input constant.
            object_map (dict[str, str]): The object map for the step.
            description (str | None, optional): The description of the step. Defaults to None.
            unit (str | None, optional): The unit of the input constant. Defaults to None.
            unit_type (str | None, optional): The unit type of the input constant. Defaults to None.
            save_time_series_external_id (str | None, optional): The external ID of the time series to save the input constant value. Defaults to None. Will be generated if not provided.
            reference_id (str | None, optional): The reference ID of the input constant. Defaults to None. Will be generated if not provided.
        """
        # input validation
        reference_id, save_time_series_external_id = self.__generic_set_get_step(
            group=group,
            name=name,
            object_map=object_map,
            description=description,
            unit=unit,
            unit_type=unit_type,
            save_time_series_external_id=save_time_series_external_id,
            reference_id=reference_id,
            step_type="SetConstant",
            value=value,
        )

        # append the InputConstant item
        self.__configuration["inputConstants"].append(
            {
                "name": name,
                "value": value,
                "unit": unit,
                "unitType": unit_type,
                "referenceId": reference_id,
                "saveTimeseriesExternalId": save_time_series_external_id,
            }
        )

        # create the routine item
        # check how many steps already exist in this group
        n_steps = len(self.__script[group - 1]["steps"])

        self.__script[group - 1]["steps"].append(
            {
                "order": n_steps + 1,
                "stepType": "Set",
                "description": description,
                "arguments": {
                    "argumentType": "inputConstant",
                    "referenceId": reference_id,
                    **object_map,
                },
            }
        )

    def add_set_step_timeseries(
        self,
        group: int,
        name: str,
        source_external_id: str,
        aggregate: Literal["average", "interpolation", "stepInterpolation"],
        object_map: dict[str, str],
        description: str | None = None,
        unit: str | None = None,
        unit_type: str | None = None,
        save_time_series_external_id: str | None = None,
        reference_id: str | None = None,
    ) -> None:
        """
        Adds a timeseries set step to the routine.

        Args:
            group (int): The group number of the step.
            name (str): The name of the step.
            source_external_id (str): The external ID of the source timeseries.
            aggregate (Literal["average", "interpolation", "stepInterpolation"]): The aggregation method for the timeseries.
            object_map (dict[str, str]): The object map for the step.
            description (str, optional): The description of the step. Defaults to None.
            unit (str, optional): The unit of the timeseries. Defaults to None.
            unit_type (str, optional): The unit type of the timeseries. Defaults to None.
            save_time_series_external_id (str, optional): The external ID of the timeseries to save the result to. Defaults to None. Will be generated if not provided.
            reference_id (str, optional): The reference ID of the step. Defaults to None. Will be generated if not provided.
        """
        # input validation
        reference_id, save_time_series_external_id = self.__generic_set_get_step(
            group=group,
            name=name,
            object_map=object_map,
            description=description,
            unit=unit,
            unit_type=unit_type,
            save_time_series_external_id=save_time_series_external_id,
            reference_id=reference_id,
            step_type="SetTimeSeries",
            source_external_id=source_external_id,
            aggregate=aggregate,
        )

        # append the inputTimeseries item
        self.__configuration["inputTimeseries"].append(
            {
                "name": name,
                "referenceId": reference_id,
                "unit": unit,
                "unitType": unit_type,
                "sourceExternalId": source_external_id,
                "aggregate": aggregate,
                "saveTimeseriesExternalId": save_time_series_external_id,
            }
        )

        # create the routine item
        # check how many steps already exist in this group
        n_steps = len(self.__script[group - 1]["steps"])

        self.__script[group - 1]["steps"].append(
            {
                "order": n_steps + 1,
                "stepType": "Set",
                "description": description,
                "arguments": {
                    "argumentType": "inputTimeSeries",
                    "referenceId": reference_id,
                    **object_map,
                },
            }
        )

    def add_get_step(
        self,
        group: int,
        name: str,
        object_map: dict[str, str],
        description: str | None = None,
        unit: str | None = None,
        unit_type: str | None = None,
        save_time_series_external_id: str | None = None,
        reference_id: str | None = None,
    ) -> None:
        """
        Adds a get step to the routine.

        Args:
            group (int): The group number of the step.
            name (str): The name of the step.
            object_map (dict[str, str]): The object map for the step.
            description (str, optional): The description of the step. Defaults to None.
            unit (str, optional): The unit of the step. Defaults to None.
            unit_type (str, optional): The unit type of the step. Defaults to None.
            save_time_series_external_id (str, optional): The external ID of the time series to save. Defaults to None. Will be generated if not provided.
            reference_id (str, optional): The reference ID of the step. Defaults to None. Will be generated if not provided.
        """
        # input validation
        reference_id, save_time_series_external_id = self.__generic_set_get_step(
            group=group,
            name=name,
            object_map=object_map,
            description=description,
            unit=unit,
            unit_type=unit_type,
            save_time_series_external_id=save_time_series_external_id,
            reference_id=reference_id,
            step_type="Get",
        )

        # append the outputTimeseries item
        self.__configuration["outputTimeseries"].append(
            {
                "name": name,
                "referenceId": reference_id,
                "unit": unit,
                "unitType": unit_type,
                "saveTimeseriesExternalId": save_time_series_external_id,
            }
        )

        # create the routine item
        # check how many steps already exist in this group
        n_steps = len(self.__script[group - 1]["steps"])

        self.__script[group - 1]["steps"].append(
            {
                "order": n_steps + 1,
                "stepType": "Get",
                "description": description,
                "arguments": {
                    "argumentType": "outputTimeSeries",
                    "referenceId": reference_id,
                    **object_map,
                },
            }
        )

    def add_command_step(
        self,
        group: int,
        command_map: dict[str, str],
        description: str | None = None,
    ) -> None:
        """
        Adds a command step to the routine.

        Args:
            group (int): The group number to which the command step belongs.
            command_map (dict[str, str]): The command map for the step.
            description (str, optional): Description of the command step. Defaults to None.
        """
        # input validation
        if not isinstance(group, int):
            raise ValueError("group needs to be of type int")

        if len(self.__script) == 0:
            raise ValueError("No groups found, please add a group first")

        if (group > self.__n_groups + 1) or (group <= 0):
            raise ValueError("Invalid value for group")

        if description and not isinstance(description, str):
            raise ValueError("description needs to be of type string")

        if not isinstance(command_map, dict):
            raise ValueError("command_map needs to be of type dictionary")

        # check if the passed dictionary contains all the variables needed for the simulator
        check_command_map(command_map, self.__simulator)

        # create the routine item
        # check how many steps already exist in this group
        n_steps = len(self.__script[group - 1]["steps"])

        self.__script[group - 1]["steps"].append(
            {
                "order": n_steps + 1,
                "stepType": "Command",
                "arguments": {
                    **command_map,
                },
            }
        )

    def get_payload(self) -> dict:
        """
        Returns the payload items for the routine revision.

        Returns:
            dict: The routine revision payload.
        """
        self.__payload_item["configuration"] = self.__configuration
        self.__payload_item["script"] = self.__script
        return {
            "items": [self.__payload_item],
        }

    def dump_payload_to_json(self, path: str = "payload.json") -> None:
        """
        Dump the payload to a JSON file.

        Args:
            path (str, optional): The path to the JSON file. Defaults to "payload.json".
        """
        with open(path, "w") as f:
            json.dump(self.get_payload(), f)

    def print_payload_item(self) -> None:
        """
        Prints the payload item in a formatted JSON string.
        """
        print(json.dumps(self.__payload_item, indent=2))

    def save_to_cdf(self) -> dict:
        """
        Saves the routine revision to CDF (Cognite Data Fusion).

        Returns:
            A dictionary containing the response from the CDF API.
        """
        return self.__sim_int_sdk.create_routine_revision(self.get_payload())
