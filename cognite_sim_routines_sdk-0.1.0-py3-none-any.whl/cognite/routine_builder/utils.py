def get_abbreviation(name: str) -> str:
    """
    Returns the abbreviation of a given name.

    Args:
        name (str): The name to generate the abbreviation for.

    Returns:
        str: The abbreviation of the name.
    """
    words = name.split()
    return "".join(word[0] for word in words).upper()


def remove_special_characters(text: str) -> str:
    """
    Removes special characters and white spaces from a given string.

    Args:
        text (str): The string to remove special characters from.

    Returns:
        str: The string without special characters.
    """
    return "".join(e for e in text if e.isalnum())


def generate_time_series_external_id(
    simulator: dict,
    routine: dict,
    reference_id: str,
    variable_type: str,
) -> str:
    simulator_id = simulator.get("name", simulator.get("externalId"))
    routine_id = routine.get("name", routine.get("externalId"))
    model_id = routine.get("modelExternalId")
    return f"{simulator_id}-{variable_type}-{routine_id}-{reference_id}-{model_id}"


def calculate_granularity_time(granularity: str) -> int:
    """
    Calculates the time in milliseconds based on the given granularity.

    Args:
        granularity (str): The granularity string in the format "<number><unit>", where
                           <number> is the magnitude and <unit> is the time unit (m, h, d).

    Returns:
        int: The calculated time in milliseconds.

    Example:
        calculate_granularity_time("5m")  # Returns 300000 (5 minutes in milliseconds)
    """
    prefix = int(granularity[0:-1])
    suffix = granularity[-1]

    granularity_ms = 0
    if suffix == "m":
        granularity_ms = 60000
    elif suffix == "h":
        granularity_ms = 60000 * 60
    elif suffix == "d":
        granularity_ms = 60000 * 60 * 24

    return prefix * granularity_ms
