from cognite.client import CogniteClient


def get_units_map(simulator: dict) -> dict:
    unit_definitions = simulator.get("units")
    if not unit_definitions:
        raise ValueError("No unit definitions found for the provided simulator")

    units_map = unit_definitions.get("unitsMap")
    if not units_map:
        raise ValueError("No unit map found for the provided simulator")

    return units_map


def check_units(unit: str, unit_type: str, simulator: dict) -> None:
    # no need to check if the unit is an empty string
    if unit == "":
        return

    units_map = get_units_map(simulator)
    unit_type_dict = units_map.get(unit_type)
    if not unit_type_dict:
        raise ValueError(
            f"Invalid unit_type ({unit_type}) for simulator {simulator.get('externalId')}"
        )

    if unit not in [item.get("value") for item in unit_type_dict.get("units")]:
        raise ValueError(f"Invalid unit ({unit}) for unit_type ({unit_type})")


def is_valid_timeseries(external_id: str, client: CogniteClient) -> bool:
    ts = client.time_series.retrieve(external_id=external_id)
    return ts is not None


def get_step_fields(simulator: dict) -> dict:
    step_fields = simulator.get("stepFields")
    if not step_fields:
        raise ValueError("No step fields found for the provided simulator")

    return step_fields


def check_object_map(object_map: dict[str, str], simulator: dict) -> None:
    step_fields = get_step_fields(simulator)

    get_set_fields = next(
        filter(lambda x: x.get("stepType") == "get/set", step_fields), None
    )
    if not get_set_fields:
        raise ValueError(
            "No get/set step configuration found for the provided simulator"
        )

    required_fields = get_set_fields.get("fields")
    if not required_fields:
        raise ValueError("No fields configuration found for the provided simulator")

    # check if the passed dictionary contains all the variables needed for the simulator
    for item in required_fields:
        if item.get("name") not in object_map.keys():
            raise ValueError(
                f"Missing required variable {item.get('name')} in the object map for {simulator.get('externalId')}"
            )


def check_command_map(command_map: dict[str, str], simulator: dict) -> None:
    step_fields = get_step_fields(simulator)

    command_fields = next(
        filter(lambda x: x.get("stepType") == "command", step_fields), None
    )
    if not command_fields:
        raise ValueError(
            "No command step configuration found for the provided simulator"
        )

    required_fields = command_fields.get("fields")
    if not required_fields:
        raise ValueError("No fields configuration found for the provided simulator")

    # check if the passed dictionary contains all the variables needed for the simulator
    for item in required_fields:
        if item.get("name") not in command_map.keys():
            raise ValueError(
                f"Missing required variable {item.get('name')} in the command map for {simulator.get('externalId')}"
            )

        # check if command have enum definitions
        allowable_values = item.get("options")
        if allowable_values:
            current_value = command_map.get(item.get("name"))
            if current_value not in [x.get("value") for x in allowable_values]:
                raise ValueError(
                    f"Invalid command value {current_value} for {simulator.get('externalId')}"
                )
