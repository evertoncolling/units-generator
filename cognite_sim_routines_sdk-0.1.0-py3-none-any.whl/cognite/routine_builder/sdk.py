from cognite.client import CogniteClient
from cognite.client.data_classes.files import FileMetadataList
from cognite.client.utils import ms_to_datetime
from datetime import datetime, timedelta, timezone
from typing import Literal


class SimIntSDK(object):
    __client: CogniteClient
    __project: str
    __headers: dict

    def __init__(self, client: CogniteClient):
        self.__client = client
        self.__project = client.config.project
        self.__headers = {"cdf-version": "alpha"}

    def list_simulators(
        self,
        enabled: bool | None = None,
        limit: int | None = None,
    ) -> list[dict]:
        """
        Retrieves a list of simulators.

        Args:
            enabled (bool, optional): Filter by enabled status. Defaults to None.
            limit (int, optional): Limit the number of results. Defaults to 1000.

        Returns:
            list[dict]: A list of simulators.
        """
        # apply filters
        payload = {}
        if enabled is not None:
            payload["filter"] = {"enabled": enabled}
        if limit is not None:
            payload["limit"] = limit

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/list",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")
        )
        return data

    def retrieve_simulator(
        self,
        simulator_external_id: str,
    ) -> dict:
        """Retrieves a simulator.

        Args:
            simulator_external_id (str): External ID of the simulator.

        Returns:
            dict: The retrieved simulator as a dictionary.
        """
        simulators = self.list_simulators()
        simulator = next(
            filter(lambda x: x.get("externalId") == simulator_external_id, simulators),
            None,
        )
        if simulator is None:
            raise ValueError(f"Simulator {simulator_external_id} not found")

        return simulator

    def list_connectors(
        self,
        simulator_external_id: str | None = None,
        limit: int | None = None,
        only_active: bool = False,
    ) -> list[dict]:
        """
        Retrieves a list of connectors.

        Args:
            simulator_external_id (str, optional): The simulator external ID to filter the connectors. Defaults to None.
            limit (int, optional): The maximum number of connectors to retrieve. Defaults to 1000.
            only_active (bool, optional): Flag to filter only active connectors. Defaults to False.

        Returns:
            list[dict]: A list of connectors.
        """
        # apply filters
        payload = {}
        if simulator_external_id is not None:
            payload["filter"] = {"simulatorExternalIds": [simulator_external_id]}
        if limit is not None:
            payload["limit"] = limit

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/integrations/list",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")
        )

        # TODO: add support for this filter on the API side
        # apply local filtering
        if only_active:
            data = [
                item
                for item in data
                if datetime.now(timezone.utc) - ms_to_datetime(item.get("heartbeat"))
                < timedelta(minutes=5)
            ]
        return data

    def retrieve_connector(
        self,
        connector_external_id: str,
    ) -> dict | None:
        """
        Retrieves a connector.

        Args:
            connector_external_id (str): The external ID of the connector to retrieve.

        Returns:
            dict | None: The retrieved connector as a dictionary, or None if not found.
        """
        connectors = self.list_connectors()
        connector = next(
            filter(lambda x: x.get("externalId") == connector_external_id, connectors),
            None,
        )
        return connector

    def list_models(
        self,
        simulator_external_id: str | None = None,
        limit: int | None = None,
    ) -> list[dict]:
        """
        Retrieves a list of simulator models.

        Args:
            simulator_external_id (str, optional): The external ID of the simulator. Defaults to None.
            limit (int, optional): The maximum number of models to retrieve. Defaults to None.

        Returns:
            list[dict]: A list of dictionaries representing the models.
        """
        # apply filters
        payload = {}
        if simulator_external_id is not None:
            payload["filter"] = {"simulatorExternalIds": [simulator_external_id]}
        if limit is not None:
            payload["limit"] = limit

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/models/list",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")
        )
        return data

    def retrieve_model(
        self,
        model_external_id: str,
    ) -> dict:
        """
        Retrieves a simulator model.

        Args:
            model_external_id (str): The external ID of the model.

        Returns:
            dict: The retrieved model data.
        """
        payload = {"items": [{"externalId": model_external_id}]}
        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/models/byids",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")[0]
        )
        return data

    def create_model(
        self,
        external_id: str,
        name: str,
        simulator_external_id: str,
        data_set_id: int,
        description: str | None = None,
        type: str | None = None,
        unit_system: str | None = None,
    ) -> dict:
        """
        Creates a simulator model.

        Args:
            external_id (str): The external ID of the model.
            name (str): The name of the model.
            simulator_external_id (str): The external ID of the simulator.
            data_set_id (int): The ID of the data set associated with the model.
            description (str, optional): The description of the model. Defaults to None.
            type (str, optional): The type of the model. Defaults to None.
            unit_system (str, optional): The unit system of the model. Defaults to None.

        Returns:
            dict: The created model data.
        """
        payload = {
            "items": [
                {
                    "externalId": external_id,
                    "name": name,
                    "simulatorExternalId": simulator_external_id,
                    "dataSetId": data_set_id,
                    "description": description,
                    "type": type,
                    "unitSystem": unit_system,
                }
            ]
        }
        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/models/",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")[0]
        )
        return data

    def delete_model(
        self,
        external_id: str,
    ) -> None:
        """Deletes a simulator model.

        Args:
            external_id (str): The external ID of the model.

        Returns:
            None
        """
        self.__client.post(
            url=f"/api/v1/projects/{self.__project}/simulators/models/delete",
            json={"items": [{"externalId": external_id}]},
            headers=self.__headers,
        )

    def create_model_revision(
        self,
        external_id: str,
        model_external_id: str,
        file_path: str,
        description: str | None = None,
    ) -> dict:
        """
        Creates a new simulator model revision.

        Args:
            external_id (str): The external ID of the model revision.
            model_external_id (str): The external ID of the model.
            file_path (str): The path to the model file.
            description (str, optional): The description of the model revision. Defaults to None.

        Returns:
            dict: The created model revision data.
        """
        model = self.retrieve_model(model_external_id)
        simulator_external_id = model.get("simulatorExternalId")

        # create a CDF file to store the model
        model_file = self.__client.files.upload(
            path=file_path,
            external_id=f"{simulator_external_id}-{model_external_id}-{external_id}",
            name=external_id,
            source=simulator_external_id,
            data_set_id=model.get("dataSetId"),
        )
        if isinstance(model_file, FileMetadataList):
            model_file = model_file[0]

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/models/revisions",
                json={
                    "items": [
                        {
                            "externalId": external_id,
                            "modelExternalId": model_external_id,
                            "description": description,
                            "fileId": model_file.id,
                            "metadata": {
                                "dataType": "Simulator File",
                                "simulator": simulator_external_id,
                                "modelName": model.get("name"),
                                "description": description,
                                "modelType": model.get("type"),
                            },
                        }
                    ]
                },
                headers=self.__headers,
            )
            .json()
            .get("items")[0]
        )
        return data

    def list_routines(
        self,
        model_external_id: str | None = None,
        simulator_integration_external_id: str | None = None,
        limit: int | None = None,
    ) -> list[dict]:
        """
        Retrieves a list of routines.

        Args:
            model_external_id (str, optional): External ID of the model to filter by. Defaults to None.
            simulator_integration_external_id (str, optional): External ID of the simulator integration to filter by. Defaults to None.
            limit (int, optional): Maximum number of routines to retrieve. Defaults to None.

        Returns:
            list[dict]: A list of dictionaries representing the retrieved routines.
        """
        # apply filters
        payload = {}
        if model_external_id is not None:
            payload["filter"] = {"modelExternalIds": [model_external_id]}
        if simulator_integration_external_id is not None:
            payload["filter"] = {
                "simulatorIntegrationExternalIds": [simulator_integration_external_id]
            }
        if limit is not None:
            payload["limit"] = limit

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/routines/list",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")
        )
        return data

    def retrieve_routine(
        self,
        routine_external_id: str,
    ) -> dict | None:
        """
        Retrieves a simulator routine.

        Args:
            routine_external_id (str): The external ID of the routine.

        Returns:
            dict | None: The routine dictionary if found, None otherwise.
        """
        routines = self.list_routines()
        routine = next(
            filter(lambda x: x.get("externalId") == routine_external_id, routines),
            None,
        )
        return routine

    def create_routine(
        self,
        external_id: str,
        name: str,
        model_external_id: str,
        simulator_integration_external_id: str,
    ) -> dict:
        """
        Creates a simulator routine.

        Args:
            external_id (str): The external ID of the routine.
            name (str): The name of the routine.
            model_external_id (str): The external ID of the model associated with the routine.
            simulator_integration_external_id (str): The external ID of the simulator integration.

        Returns:
            dict: The created routine data.
        """
        payload = {
            "items": [
                {
                    "externalId": external_id,
                    "name": name,
                    "modelExternalId": model_external_id,
                    "simulatorIntegrationExternalId": simulator_integration_external_id,
                }
            ]
        }
        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/routines/",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")[0]
        )
        return data

    def delete_routine(
        self,
        external_id: str,
    ) -> None:
        """Deletes a simulator routine.

        Args:
            external_id (str): The external ID of the routine to delete.

        Returns:
            None
        """
        self.__client.post(
            url=f"/api/v1/projects/{self.__project}/simulators/routines/delete",
            json={"items": [{"externalId": external_id}]},
            headers=self.__headers,
        )

    def list_routine_revisions(
        self,
        routine_external_ids: list[str] | None = None,
        limit: int | None = None,
    ) -> list[dict]:
        """
        Retrieves a list of routine revisions.

        Args:
            routine_external_ids (list[str] | None): Optional. List of routine external IDs to filter by.
            limit (int | None): Optional. Maximum number of routine revisions to retrieve.

        Returns:
            list[dict]: A list of routine revision items matching the provided filters.
        """
        # apply filters
        payload = {}
        if routine_external_ids is not None:
            payload["filter"] = {"routineExternalIds": routine_external_ids}
        if limit is not None:
            payload["limit"] = limit

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/routines/revisions/list",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")
        )
        return data

    def retrieve_routine_revision(
        self,
        external_id: str,
    ) -> dict | None:
        """Retrieves a simulator routine revision.

        Args:
            external_id (str): The external ID of the routine revision.

        Returns:
            dict | None: The routine revision dictionary if found, None otherwise.
        """
        revisions = self.list_routine_revisions()
        revision = next(
            filter(lambda x: x.get("externalId") == external_id, revisions),
            None,
        )
        return revision

    def create_routine_revision(
        self,
        payload: dict,
    ) -> dict:
        """
        Creates a new revision of a routine.

        Args:
            payload (dict): The payload containing the details of the routine revision.

        Returns:
            dict: The data of the newly created routine revision.
        """
        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/routines/revisions",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")[0]
        )
        return data

    def run_simulation(
        self,
        routine_external_id: str,
        queue: bool | None = None,
        validation_end_time: int | None = None,
    ) -> dict:
        """
        Run a single simulation routine.

        Args:
            routine_external_id (str): The external ID of the routine to run.
            queue (bool, optional): Whether to qeue the simulation run when connector is down. Defaults to None.
            validation_end_time (int, optional): Timestamp that overrides the validation end. Defaults to None.

        Returns:
            dict: The data of the simulation run.
        """
        item: dict = {"routineExternalId": routine_external_id}
        if queue is not None:
            item["queue"] = queue

        if validation_end_time is not None:
            item["validationEndTime"] = validation_end_time

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/run",
                json={"items": [item]},
                headers=self.__headers,
            )
            .json()
            .get("items")[0]
        )
        return data

    def list_simulation_runs(
        self,
        simulator_external_ids: list[str] | None = None,
        simulator_integration_external_ids: list[str] | None = None,
        routine_revision_external_ids: list[str] | None = None,
        model_revision_external_ids: list[str] | None = None,
        status: Literal["ready", "running", "success", "failure"] | None = None,
        limit: int | None = None,
    ) -> list[dict]:
        """List simulation runs.

        Args:
            simulator_external_ids (list[str] | None): Optional. List of simulator external IDs to filter by.
            simulator_integration_external_ids (list[str] | None): Optional. List of simulator integration external IDs to filter by.
            routine_revision_external_ids (list[str] | None): Optional. List of routine revision external IDs to filter by.
            model_revision_external_ids (list[str] | None): Optional. List of model revision external IDs to filter by.
            status (Literal["ready", "running", "success", "failure"] | None): Optional. Status of the simulation runs to filter by.
            limit (int | None): Optional. Maximum number of simulation runs to retrieve.

        Returns:
            list[dict]: A list of simulation run items matching the provided filters.
        """
        # apply filters
        filter = {}
        if simulator_external_ids is not None:
            filter["simulatorExternalIds"] = simulator_external_ids
        if simulator_integration_external_ids is not None:
            filter["simulatorIntegrationExternalIds"] = simulator_integration_external_ids
        if routine_revision_external_ids is not None:
            filter["routineRevisionExternalIds"] = routine_revision_external_ids
        if model_revision_external_ids is not None:
            filter["modelRevisionExternalIds"] = model_revision_external_ids
        if status is not None:
            filter["status"] = status

        payload = {}
        if filter:
            payload["filter"] = filter
        if limit is not None:
            payload["limit"] = limit

        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/runs/list",
                json=payload,
                headers=self.__headers,
            )
            .json()
            .get("items")
        )
        return data

    def retrieve_simulation_run(
        self,
        id: int
    ) -> dict:
        """Retrieves a simulation run.

        Args:
            id (int): The ID of the simulation run.

        Returns:
            dict: The data of the simulation run.
        """
        data = (
            self.__client.post(
                url=f"/api/v1/projects/{self.__project}/simulators/runs/byids",
                json={"items": [{"id": id}]},
                headers=self.__headers,
            )
            .json()
        )
        return data
